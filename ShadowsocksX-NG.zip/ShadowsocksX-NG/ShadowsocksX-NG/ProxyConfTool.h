//
//  ProxyConfTool.h
//  ShadowsocksX-NG
//
//  Created by 邱宇舟 on 16/6/29.
//  Copyright © 2016年 qiuyuzhou. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ProxyConfTool : NSObject

+(NSArray*)networkServicesList;

@end
