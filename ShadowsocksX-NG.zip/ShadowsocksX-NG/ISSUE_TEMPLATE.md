**System and Shadowsocksx-NG-R8 version:**

- macOS 10.12.4 beta (16E144f)
- Shadowsocksx-NG-R8 1.3.9-build4

**Expected behavior:**



**Actual behavior:**

(N/A for feature requests)

**Steps to reproduce:**

(N/A for feature requests)

**How often does this happen?**

(N/A for feature requests)

**ss-local.log**

Please upload the ss-local.log file here the file is in `~/Library/Logs`
1) Open 'Advanced Settings -> enable Verbose Mode'
2) Continue run `Shadowsocksx-NG-R8` for 5 minutes
3) Upload the `~/Library/Logs/ss-local.log` here (with or without compress)

**Application log**

Open the `Console.app` and search `Shadowsocksx-NG`
Copy paste the log here

**Crash Log**

If the app crashes and pop up a crash log, please copy and paste here

**Tips:**

- Always check for the latest update, some known bug has been fix in the latest release such as old version not support auth_aes_md5 auth_aes_sha1

- Beta version of macOS also may couse some problems

- ss-local compiled by macOS Sierra 10.12 not compatite with 10.11, some old release's ss-local are compiled using 10.12 will not work on 10.11, new release are try build in 10.10 to max fit the compatite

