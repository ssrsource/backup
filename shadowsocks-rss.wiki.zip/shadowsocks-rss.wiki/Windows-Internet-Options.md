如果你在Windows 7/8/10下，新安装的系统，运行Shadowsocks后，发现IE无法通过ss连接，同时在ssr的统计窗口内没有产生任何统计信息的话，很可能是没有关闭系统的安全选项，这种情况下系统将拒绝连接到localhost(127.0.0.1)

打开你的Internet选项，找到如下页面

![](https://raw.github.com/breakwa11/shadowsocks-rss/master/img/ssie.png)

在红框处取消打钩，然后重启IE或MS edge即可